##########################################################################################
# AutoPurge Pro (WebUI增强版) 安装脚本
# Author: liancan
##########################################################################################
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

print_modname() {
    ui_print "===================================================="
    ui_print "   AutoPurge Pro (WebUI增强版) v2.1.0"
    ui_print "   模块作者: liancan"
    ui_print "===================================================="
    ui_print " - 集成 KernelSU / APatch / MMRL WebUI 可视化控制面板"
    ui_print " - 支持黑白名单与MT规则在线管理、搜索与源码编辑"
    ui_print " - 支持累计清理统计面板与历史清理文件明细追溯"
    ui_print " - 支持双时段定时任务配置与模块功能总开关"
    ui_print " - 配置目录: /sdcard/Android/Clear/清理垃圾/"
    ui_print "===================================================="
}

on_install() {
    ui_print "- 正在解压模块核心文件..."
    unzip -o "$ZIPFILE" -x "META-INF/*" -x "install.sh" -d "$MODPATH" >/dev/null 2>&1

    TARGET_DIR="/data/media/0/Android/Clear/清理垃圾"
    mkdir -p "$TARGET_DIR/名单配置" "$TARGET_DIR/自定义定时设置"

    # 智能升级策略：保留用户已有的自定义配置与累计统计数据
    if [ ! -f "$TARGET_DIR/名单配置/黑名单.conf" ]; then
        cp -f "$MODPATH/Configuration_File/名单配置/黑名单.conf" "$TARGET_DIR/名单配置/黑名单.conf"
    else
        ui_print "- 检测到已有黑名单配置，保留用户数据并备份新模板为 黑名单.conf.default"
        cp -f "$MODPATH/Configuration_File/名单配置/黑名单.conf" "$TARGET_DIR/名单配置/黑名单.conf.default"
    fi

    if [ ! -f "$TARGET_DIR/名单配置/白名单.conf" ]; then
        cp -f "$MODPATH/Configuration_File/名单配置/白名单.conf" "$TARGET_DIR/名单配置/白名单.conf"
    fi

    if [ ! -f "$TARGET_DIR/名单配置/MT.conf" ]; then
        cp -f "$MODPATH/Configuration_File/名单配置/MT.conf" "$TARGET_DIR/名单配置/MT.conf"
    fi

    if [ ! -f "$TARGET_DIR/配置.conf" ]; then
        cp -f "$MODPATH/Configuration_File/配置.conf" "$TARGET_DIR/配置.conf"
    else
        grep -q "^master_switch=" "$TARGET_DIR/配置.conf" || sed -i '1i master_switch=true' "$TARGET_DIR/配置.conf"
    fi

    if [ ! -f "$TARGET_DIR/自定义定时设置/定时设置.conf" ]; then
        cp -f "$MODPATH/Configuration_File/自定义定时设置/定时设置.conf" "$TARGET_DIR/自定义定时设置/定时设置.conf"
    fi

    cp -f "$MODPATH/Configuration_File/自定义定时设置/Timing_Settings.sh" "$TARGET_DIR/自定义定时设置/Timing_Settings.sh"

    [ ! -f "$TARGET_DIR/Counter" ] && printf "目录=0\n文件=0\n" > "$TARGET_DIR/Counter"
    [ ! -f "$TARGET_DIR/Clear.log" ] && touch "$TARGET_DIR/Clear.log"
    [ ! -f "$TARGET_DIR/History_Files.log" ] && touch "$TARGET_DIR/History_Files.log"

    rm -rf "$MODPATH/Configuration_File"
    ui_print "- 正在设置文件执行权限..."
}

set_permissions() {
    set_perm_recursive "$MODPATH" 0 0 0755 0644
    set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
    set_perm_recursive "$MODPATH/Service_Config" 0 0 0755 0755
    set_perm "$MODPATH/Main.sh" 0 0 0755
    set_perm "$MODPATH/action.sh" 0 0 0755
    set_perm "$MODPATH/service.sh" 0 0 0755
    set_perm "$MODPATH/uninstall.sh" 0 0 0755
    chmod 2770 "/data/media/0/Android/Clear/清理垃圾/名单配置" 2>/dev/null
    chmod 2770 "/data/media/0/Android/Clear/清理垃圾/自定义定时设置" 2>/dev/null
    chmod 0755 "/data/media/0/Android/Clear/清理垃圾/自定义定时设置/Timing_Settings.sh" 2>/dev/null
    find "/data/media/0/Android/Clear/清理垃圾/" -type f -name "*.conf" -exec chmod 644 {} + 2>/dev/null
    ui_print "- 安装完成！可在 KernelSU / APatch 管理器中打开 WebUI 面板进行配置。"
}
