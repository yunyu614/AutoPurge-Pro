#!/system/bin/sh
# AutoPurge Pro 定时任务重载脚本
# Author: liancan

MODDIR="/data/adb/modules/Clear_Rubbish"
[ ! -d "$MODDIR" ] && MODDIR="/data/adb/ksu/modules/Clear_Rubbish"
CONFIG_DIR="/data/media/0/Android/Clear/清理垃圾"
config_file="$CONFIG_DIR/自定义定时设置/定时设置.conf"
main_conf="$CONFIG_DIR/配置.conf"

if [ ! -f "$config_file" ]; then
    echo "错误: 配置文件 $config_file 不存在"
    exit 1
fi

validate_num() {
    local val="$1"
    local min="$2"
    local max="$3"
    [ "$val" = "*" ] && return 0
    echo "$val" | grep -qE '^[0-9]+$' || return 1
    [ "$val" -ge "$min" ] && [ "$val" -le "$max" ] && return 0
    return 1
}

Set_Time1=$(grep -E '^Set_Time1=' "$config_file" | head -n1 | cut -d'=' -f2 | tr -d ' \r')
Set_minute1=$(grep -E '^Set_minute1=' "$config_file" | head -n1 | cut -d'=' -f2 | tr -d ' \r')
Set_Time2=$(grep -E '^Set_Time2=' "$config_file" | head -n1 | cut -d'=' -f2 | tr -d ' \r')
Set_minute2=$(grep -E '^Set_minute2=' "$config_file" | head -n1 | cut -d'=' -f2 | tr -d ' \r')
Set_weekday1=$(grep -E '^Set_weekday1=' "$config_file" | head -n1 | cut -d'=' -f2 | tr -d ' \r')
Set_weekday2=$(grep -E '^Set_weekday2=' "$config_file" | head -n1 | cut -d'=' -f2 | tr -d ' \r')

[ -z "$Set_Time1" ] && Set_Time1="0"
[ -z "$Set_minute1" ] && Set_minute1="0"
[ -z "$Set_Time2" ] && Set_Time2="12"
[ -z "$Set_minute2" ] && Set_minute2="0"
[ -z "$Set_weekday1" ] && Set_weekday1="*"
[ -z "$Set_weekday2" ] && Set_weekday2="*"

if ! validate_num "$Set_Time1" 0 23 || ! validate_num "$Set_Time2" 0 23; then
    echo "错误: 小时必须在 0-23 之间或为 *"
    exit 1
fi
if ! validate_num "$Set_minute1" 0 59 || ! validate_num "$Set_minute2" 0 59; then
    echo "错误: 分钟必须在 0-59 之间或为 *"
    exit 1
fi
if ! validate_num "$Set_weekday1" 1 7 || ! validate_num "$Set_weekday2" 1 7; then
    echo "错误: 星期必须在 1-7 之间或为 *"
    exit 1
fi

[ "$Set_minute1" = "00" ] && Set_minute1="0"
[ "$Set_minute2" = "00" ] && Set_minute2="0"

mkdir -p "$MODDIR/cron.d"
Cron_Time1="$Set_minute1 $Set_Time1 * * $Set_weekday1"
Cron_Time2="$Set_minute2 $Set_Time2 * * $Set_weekday2"

echo "$Cron_Time1 /system/bin/sh $MODDIR/Main.sh" > "$MODDIR/cron.d/root"
if [ "$Cron_Time1" != "$Cron_Time2" ]; then
    echo "$Cron_Time2 /system/bin/sh $MODDIR/Main.sh" >> "$MODDIR/cron.d/root"
fi
chmod 644 "$MODDIR/cron.d/root"

# 重启模块专属 crond 进程
for pid in $(ps -ef 2>/dev/null | grep "crond" | grep "Clear_Rubbish" | awk '{print $2}'); do
    kill -9 "$pid" 2>/dev/null
done
pkill -f "crond -c $MODDIR/cron.d" 2>/dev/null

master_switch=$(grep -E '^master_switch=' "$main_conf" 2>/dev/null | cut -d'=' -f2 | tr -d ' \r')
timed_cleaning=$(grep -E '^timed_cleaning=' "$main_conf" 2>/dev/null | cut -d'=' -f2 | tr -d ' \r')

if [ "$master_switch" != "false" ] && [ "$timed_cleaning" != "false" ]; then
    if [ -x "/data/adb/ksu/bin/busybox" ]; then
        /data/adb/ksu/bin/busybox crond -c "$MODDIR/cron.d/"
    elif [ -x "/data/adb/ap/bin/busybox" ]; then
        /data/adb/ap/bin/busybox crond -c "$MODDIR/cron.d/"
    elif command -v magisk >/dev/null 2>&1; then
        "$(magisk --path)/.magisk/busybox/crond" -c "$MODDIR/cron.d/"
    elif command -v busybox >/dev/null 2>&1; then
        busybox crond -c "$MODDIR/cron.d/"
    fi
    echo "定时任务已更新并启动: [$Cron_Time1] & [$Cron_Time2]"
else
    echo "定时配置已保存 (当前定时开关或总开关处于关闭状态，crond未启动)"
fi
