/**
 * AutoPurge Pro WebUI Frontend Controller
 * Author: liancan
 * Supports KernelSU / KernelSU Next / APatch / MMRL WebView Bridge + Preview Sandbox
 */

const MODDIR = "/data/adb/modules/Clear_Rubbish";
const CONFIG_DIR = "/data/media/0/Android/Clear/清理垃圾";
const CTL_SCRIPT = `${MODDIR}/bin/autopurge_ctl.sh`;

const FILE_PATHS = {
  blacklist: `${CONFIG_DIR}/名单配置/黑名单.conf`,
  whitelist: `${CONFIG_DIR}/名单配置/白名单.conf`,
  mtlist: `${CONFIG_DIR}/名单配置/MT.conf`,
  main_conf: `${CONFIG_DIR}/配置.conf`,
  timing_conf: `${CONFIG_DIR}/自定义定时设置/定时设置.conf`,
  timing_sh: `${CONFIG_DIR}/自定义定时设置/Timing_Settings.sh`,
  clear_log: `${CONFIG_DIR}/Clear.log`,
  history_log: `${CONFIG_DIR}/History_Files.log`
};

// State
let currentRuleType = "blacklist";
let isRawEditMode = false;
let currentRuleLines = [];
let rawRuleContentCache = {
  blacklist: "# 应用缓存\n/data/data/*/cache/*\n/data/media/0/Android/data/*/cache/*\n# 2345残留垃圾目录\n/data/media/0/2345*\n/data/media/0/Android/data/com.market2345/cache/*",
  whitelist: "# 白名单保护路径\n/sdcard/*\n/data/adb/*\n/data/media/0/DCIM/\n/data/media/0/Pictures/\n/data/media/0/Download/",
  mtlist: "/data/media/0/.*\n/data/media/0/QQBrowser/\n/data/media/0/MT2/.recycle/\n/data/media/0/ramdump/"
};
let historyEntries = [];
let currentHistoryFilter = "ALL";

// Native KernelSU WebView Bridge Wrapper
let cbCounter = 0;
function isKsuEnv() {
  return typeof window.ksu !== "undefined" && typeof window.ksu.exec === "function";
}

function execRootCmd(command) {
  return new Promise((resolve) => {
    if (isKsuEnv()) {
      const cbName = `ksu_cb_${Date.now()}_${++cbCounter}`;
      window[cbName] = (errno, stdout, stderr) => {
        delete window[cbName];
        resolve({ errno: Number(errno), stdout: stdout || "", stderr: stderr || "" });
      };
      try {
        window.ksu.exec(command, JSON.stringify({}), cbName);
      } catch (e) {
        delete window[cbName];
        resolve({ errno: 1, stdout: "", stderr: String(e) });
      }
    } else {
      // Browser preview fallback simulation
      resolve({ errno: 0, stdout: "", stderr: "" });
    }
  });
}

function showToast(msg) {
  if (isKsuEnv() && typeof window.ksu.toast === "function") {
    window.ksu.toast(msg);
  }
  const box = document.getElementById("toastBox");
  if (!box) return;
  box.textContent = msg;
  box.classList.add("show");
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => box.classList.remove("show"), 2400);
}

// Base64 UTF-8 safe helpers for writing config files via shell without escaping issues
function utf8ToB64(str) {
  return window.btoa(unescape(encodeURIComponent(str)));
}

async function readRootFile(path) {
  if (!isKsuEnv()) {
    return rawRuleContentCache[currentRuleType] || "";
  }
  const { errno, stdout } = await execRootCmd(`cat "${path}" 2>/dev/null`);
  return errno === 0 ? stdout : "";
}

async function writeRootFile(path, content, mode = "644") {
  if (!isKsuEnv()) {
    rawRuleContentCache[currentRuleType] = content;
    return true;
  }
  const b64 = utf8ToB64(content);
  const cmd = `echo "${b64}" | base64 -d > "${path}" && chmod ${mode} "${path}"`;
  const { errno } = await execRootCmd(cmd);
  return errno === 0;
}

function formatSizeFromKB(kb) {
  const num = Number(kb) || 0;
  if (num >= 1048576) {
    return (num / 1048576).toFixed(2) + " GB";
  }
  if (num >= 1024) {
    return (num / 1024).toFixed(1) + " MB";
  }
  return num + " KB";
}

// Tab Navigation
function switchTab(tabId) {
  document.querySelectorAll(".tab-pane").forEach((el) => el.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach((el) => el.classList.remove("active"));
  const targetPane = document.getElementById(`tab-${tabId}`);
  const targetNav = document.getElementById(`nav-${tabId}`);
  if (targetPane) targetPane.classList.add("active");
  if (targetNav) targetNav.classList.add("active");

  if (tabId === "dashboard") refreshDashboard();
  if (tabId === "rules") reloadCurrentRuleFile();
  if (tabId === "history") loadHistoryAndLogs();
}

// Populate Schedule Selectors (0-23 hours, 0-59 minutes)
function initScheduleSelects() {
  const hSelects = [document.getElementById("selTime1"), document.getElementById("selTime2")];
  const mSelects = [document.getElementById("selMin1"), document.getElementById("selMin2")];

  hSelects.forEach((sel) => {
    if (!sel) return;
    let html = `<option value="*">每小时 (*)</option>`;
    for (let h = 0; h <= 23; h++) {
      html += `<option value="${h}">${String(h).padStart(2, "0")} 时 (${h})</option>`;
    }
    sel.innerHTML = html;
  });

  mSelects.forEach((sel) => {
    if (!sel) return;
    let html = `<option value="*">每分钟 (*)</option>`;
    for (let m = 0; m <= 59; m++) {
      const val = m === 0 ? "00" : String(m);
      html += `<option value="${val}">${String(m).padStart(2, "0")} 分</option>`;
    }
    sel.innerHTML = html;
  });

  document.getElementById("selTime1").value = "0";
  document.getElementById("selMin1").value = "00";
  document.getElementById("selTime2").value = "12";
  document.getElementById("selMin2").value = "00";
  updateCronPreview();
}

function updateCronPreview() {
  const t1 = document.getElementById("selTime1").value;
  const m1 = document.getElementById("selMin1").value;
  const w1 = document.getElementById("selWeek1").value;
  const t2 = document.getElementById("selTime2").value;
  const m2 = document.getElementById("selMin2").value;
  const w2 = document.getElementById("selWeek2").value;

  const m1Clean = m1 === "00" ? "0" : m1;
  const m2Clean = m2 === "00" ? "0" : m2;
  document.getElementById("cronPreview1").textContent = `Cron: ${m1Clean} ${t1} * * ${w1}`;
  document.getElementById("cronPreview2").textContent = `Cron: ${m2Clean} ${t2} * * ${w2}`;
}

function applySchedulePreset(t1, m1, w1, t2, m2, w2) {
  document.getElementById("selTime1").value = t1;
  document.getElementById("selMin1").value = m1;
  document.getElementById("selWeek1").value = w1;
  document.getElementById("selTime2").value = t2;
  document.getElementById("selMin2").value = m2;
  document.getElementById("selWeek2").value = w2;
  updateCronPreview();
  showToast("已填入预设时间，请点击保存生效");
}

async function saveScheduleSettings() {
  const t1 = document.getElementById("selTime1").value;
  const m1 = document.getElementById("selMin1").value;
  const w1 = document.getElementById("selWeek1").value;
  const t2 = document.getElementById("selTime2").value;
  const m2 = document.getElementById("selMin2").value;
  const w2 = document.getElementById("selWeek2").value;

  const content = `# AutoPurge Pro 定时清理配置 (Author: liancan)
# - 【时间1】
Set_Time1=${t1}
Set_minute1=${m1}

# - 【时间2】
Set_Time2=${t2}
Set_minute2=${m2}

# - 【星期设定 1】
Set_weekday1=${w1}

# - 【星期设定 2】
Set_weekday2=${w2}
`;

  const ok = await writeRootFile(FILE_PATHS.timing_conf, content, "644");
  if (!ok) {
    showToast("保存定时配置文件失败");
    return;
  }
  if (isKsuEnv()) {
    const { stdout } = await execRootCmd(`sh "${FILE_PATHS.timing_sh}"`);
    showToast(stdout.trim() || "定时配置已生效！");
  } else {
    showToast("定时配置已保存 (预览模式)");
  }
  refreshDashboard();
}

// Dashboard Data Loading
async function refreshDashboard() {
  if (isKsuEnv()) {
    const { errno, stdout } = await execRootCmd(`sh "${CTL_SCRIPT}" status`);
    if (errno === 0 && stdout) {
      try {
        const data = JSON.parse(stdout);
        renderDashboardData(data);
        return;
      } catch (e) {
        console.error("Failed to parse status JSON:", e);
      }
    }
  } else {
    renderDashboardData({
      config: {
        master_switch: true,
        timed_cleaning: true,
        mt_cleaning: true,
        log_cleaning: true,
        log_purge_size: "2M"
      },
      schedule: { t1: "0", m1: "00", w1: "*", t2: "12", m2: "00", w2: "*" },
      stats: {
        total_files: 1842,
        total_dirs: 316,
        total_runs: 28,
        total_freed_kb: 1482940,
        last_run_files: 64,
        last_run_dirs: 12,
        last_clean_time: "2026-11-02 11:30:00",
        bl_count: 492,
        wl_count: 18,
        mt_count: 31,
        log_size_bytes: 18432
      },
      daemons: { main_control: true, smart_clear: true, log_clear: true, crond: true },
      storage: { total_kb: 251658240, used_kb: 118489088, avail_kb: 133169152 }
    });
  }
}

function renderDashboardData(data) {
  const cfg = data.config || {};
  const st = data.stats || {};
  const dm = data.daemons || {};
  const sc = data.schedule || {};
  const disk = data.storage || {};

  // Master switch UI
  const masterOn = cfg.master_switch !== false;
  document.getElementById("swMaster").checked = masterOn;
  document.getElementById("masterStatusTitle").textContent = masterOn ? "🟢 模块运行中" : "⏸️ 模块已暂停";
  document.getElementById("masterStatusDesc").textContent = masterOn
    ? "后台守护与定时清理服务已激活动态监控"
    : "所有后台自动清理任务与守护进程已暂停";

  // Sub-switches
  document.getElementById("swTimed").checked = cfg.timed_cleaning !== false;
  document.getElementById("swMt").checked = cfg.mt_cleaning !== false;
  document.getElementById("swLog").checked = cfg.log_cleaning !== false;
  if (cfg.log_purge_size) {
    document.getElementById("selLogSize").value = cfg.log_purge_size;
  }

  // Daemons
  setDot("dotMain", dm.main_control);
  setDot("dotCron", dm.crond);
  setDot("dotSmart", dm.smart_clear);
  setDot("dotLog", dm.log_clear);

  // Stats
  document.getElementById("statTotalFiles").textContent = Number(st.total_files || 0).toLocaleString();
  document.getElementById("statTotalDirs").textContent = Number(st.total_dirs || 0).toLocaleString();
  document.getElementById("statLastFiles").textContent = `上次清理: +${st.last_run_files || 0} 个文件`;
  document.getElementById("statLastDirs").textContent = `上次清理: +${st.last_run_dirs || 0} 个目录`;
  document.getElementById("statTotalFreed").textContent = formatSizeFromKB(st.total_freed_kb || 0);
  document.getElementById("statTotalRuns").textContent = `累计执行: ${st.total_runs || 0} 次`;
  document.getElementById("statLastTime").textContent = st.last_clean_time || "尚未执行";

  const pad2 = (v) => (v === "*" ? "*" : String(v).padStart(2, "0"));
  document.getElementById("statCronSummary").textContent = `定时: ${pad2(sc.t1)}:${pad2(sc.m1)} & ${pad2(sc.t2)}:${pad2(sc.m2)}`;

  // Badges & Log size
  document.getElementById("badgeBlCount").textContent = st.bl_count || 0;
  document.getElementById("badgeWlCount").textContent = st.wl_count || 0;
  document.getElementById("badgeMtCount").textContent = st.mt_count || 0;
  document.getElementById("curLogSizeDesc").textContent = `当前 Clear.log 大小: ${(Number(st.log_size_bytes || 0) / 1024).toFixed(1)} KB`;

  // Storage bar
  if (disk.total_kb > 0) {
    const pct = Math.min(100, Math.round((disk.used_kb / disk.total_kb) * 100));
    document.getElementById("storageBarFill").style.width = `${pct}%`;
    document.getElementById("storagePercentText").textContent = `已用 ${pct}%`;
    document.getElementById("storageUsedText").textContent = `已用: ${(disk.used_kb / 1048576).toFixed(1)} GB`;
    document.getElementById("storageAvailText").textContent = `可用: ${(disk.avail_kb / 1048576).toFixed(1)} GB`;
  }

  // Sync schedule dropdowns
  if (sc.t1 !== undefined) document.getElementById("selTime1").value = String(sc.t1);
  if (sc.m1 !== undefined) document.getElementById("selMin1").value = sc.m1 === "0" ? "00" : String(sc.m1);
  if (sc.w1 !== undefined) document.getElementById("selWeek1").value = String(sc.w1);
  if (sc.t2 !== undefined) document.getElementById("selTime2").value = String(sc.t2);
  if (sc.m2 !== undefined) document.getElementById("selMin2").value = sc.m2 === "0" ? "00" : String(sc.m2);
  if (sc.w2 !== undefined) document.getElementById("selWeek2").value = String(sc.w2);
  updateCronPreview();
  if (typeof applyUiPrefs === "function") applyUiPrefs();
}

function setDot(id, isOn) {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = "dot " + (isOn ? "on" : "off");
}

// Switch & Config Handlers
async function onToggleSwitch(key, checked) {
  const val = checked ? "true" : "false";
  if (isKsuEnv()) {
    const cmd = `
      if grep -qE "^[[:space:]]*${key}[[:space:]]*=" "${FILE_PATHS.main_conf}"; then
        sed -i "s|^[[:space:]]*${key}[[:space:]]*=.*|${key}=${val}|g" "${FILE_PATHS.main_conf}"
      else
        echo "${key}=${val}" >> "${FILE_PATHS.main_conf}"
      fi
      sh "${CTL_SCRIPT}" apply
    `;
    await execRootCmd(cmd);
    showToast(`已${checked ? "开启" : "关闭"} ${key}`);
    refreshDashboard();
  } else {
    showToast(`已${checked ? "开启" : "关闭"} ${key} (预览模式)`);
  }
}

async function onChangeLogSize(val) {
  if (isKsuEnv()) {
    const cmd = `
      sed -i "s|^[[:space:]]*log_purge_size[[:space:]]*=.*|log_purge_size=${val}|g" "${FILE_PATHS.main_conf}"
      pkill -f LogClear 2>/dev/null
      sh "${CTL_SCRIPT}" apply
    `;
    await execRootCmd(cmd);
    showToast(`日志清理阈值已设为 ${val}`);
  } else {
    showToast(`日志清理阈值已设为 ${val} (预览模式)`);
  }
}

async function triggerCleanup(mode) {
  const btnId = mode === "mt" ? "btnCleanMT" : "btnCleanAll";
  const btn = document.getElementById(btnId);
  if (!btn || btn.disabled) return;
  const origText = btn.textContent;
  btn.disabled = true;
  btn.textContent = "⏳ 正在启动清理...";

  try {
    if (!isKsuEnv()) {
      await new Promise((r) => setTimeout(r, 600));
      showToast("清理完成！已删除 23 个文件，5 个目录 (预览)");
      return;
    }

    const startRes = await execRootCmd(`sh "${CTL_SCRIPT}" start_clean ${mode}`);
    let startInfo = {};
    try { startInfo = JSON.parse((startRes.stdout || "{}").trim().split("\n").pop()); } catch (_) {}
    if (startRes.errno !== 0 || !["started", "already_running"].includes(startInfo.status)) {
      throw new Error(startRes.stderr || "无法启动清理任务");
    }
    showToast(startInfo.status === "already_running" ? "已有清理任务正在执行，请稍候" : "清理任务已在后台启动，界面可继续操作");
    btn.textContent = "⏳ 后台清理中...";

    const startedAt = Date.now();
    let finished = false;
    while (!finished && Date.now() - startedAt < 30 * 60 * 1000) {
      await new Promise((r) => setTimeout(r, 1800));
      const statusRes = await execRootCmd(`sh "${CTL_SCRIPT}" clean_status`);
      let status = {};
      try { status = JSON.parse((statusRes.stdout || "{}").trim().split("\n").pop()); } catch (_) {}
      if (status.status === "done") {
        finished = true;
        showToast(status.success ? "清理已完成" : "清理任务结束，请查看运行日志");
        break;
      }
      if (status.status === "idle") {
        finished = true;
        showToast("清理任务状态已结束，请刷新统计或查看日志");
      }
    }
    if (!finished) showToast("清理仍在后台运行，可稍后查看清理记录");
    await refreshDashboard();
  } catch (e) {
    showToast(`清理启动失败：${String(e.message || e).slice(0, 80)}`);
  } finally {
    btn.disabled = false;
    btn.textContent = origText;
  }
}

// Rules Management (Blacklist / Whitelist / MT.conf)
function switchRuleType(type) {
  currentRuleType = type;
  document.getElementById("segBtnBlacklist").classList.toggle("active", type === "blacklist");
  document.getElementById("segBtnWhitelist").classList.toggle("active", type === "whitelist");
  document.getElementById("segBtnMtlist").classList.toggle("active", type === "mtlist");
  document.getElementById("currentRuleFilePath").textContent = FILE_PATHS[type];
  reloadCurrentRuleFile();
}

function toggleRuleEditMode() {
  isRawEditMode = !isRawEditMode;
  document.getElementById("visualRuleView").style.display = isRawEditMode ? "none" : "block";
  document.getElementById("rawRuleView").style.display = isRawEditMode ? "block" : "none";
  document.getElementById("btnToggleEditMode").textContent = isRawEditMode ? "📋 切换列表模式" : "📝 切换源码模式";

  if (isRawEditMode) {
    document.getElementById("rawRuleTextarea").value = serializeRuleLines();
  } else {
    parseRuleTextToLines(document.getElementById("rawRuleTextarea").value);
    renderVisualRuleList();
  }
}

async function reloadCurrentRuleFile() {
  const path = FILE_PATHS[currentRuleType];
  const content = await readRootFile(path);
  document.getElementById("rawRuleTextarea").value = content;
  parseRuleTextToLines(content);
  renderVisualRuleList();
}

function parseRuleTextToLines(text) {
  const rawLines = (text || "").replace(/\r/g, "").split("\n");
  currentRuleLines = [];
  let pendingCategory = "";

  for (let i = 0; i < rawLines.length; i++) {
    const trimmed = rawLines[i].trim();
    if (!trimmed) {
      currentRuleLines.push({ type: "empty", raw: "" });
      continue;
    }
    // Check if it is a commented out path like #/data/...
    if (/^#\s*\//.test(trimmed)) {
      const cleanPath = trimmed.replace(/^#\s*/, "");
      currentRuleLines.push({
        type: "rule",
        path: cleanPath,
        enabled: false,
        category: pendingCategory
      });
    } else if (trimmed.startsWith("#")) {
      pendingCategory = trimmed.replace(/^#+\s*/, "");
      currentRuleLines.push({ type: "comment", text: trimmed });
    } else {
      currentRuleLines.push({
        type: "rule",
        path: trimmed,
        enabled: true,
        category: pendingCategory
      });
    }
  }
}

function serializeRuleLines() {
  return currentRuleLines
    .map((item) => {
      if (item.type === "empty") return "";
      if (item.type === "comment") return item.text;
      return item.enabled ? item.path : `#${item.path}`;
    })
    .join("\n");
}

function renderVisualRuleList() {
  const container = document.getElementById("visualRuleList");
  const keyword = (document.getElementById("inpSearchRule").value || "").trim().toLowerCase();
  let html = "";
  let activeCount = 0;

  currentRuleLines.forEach((item, idx) => {
    if (item.type !== "rule") return;
    if (item.enabled) activeCount++;
    if (keyword && !item.path.toLowerCase().includes(keyword) && !(item.category || "").toLowerCase().includes(keyword)) {
      return;
    }
    html += `
      <div class="rule-row ${item.enabled ? "" : "commented"}">
        <div style="flex:1;min-width:0;">
          <div class="rule-path">${escapeHtml(item.path)}</div>
          ${item.category ? `<span class="rule-note">${escapeHtml(item.category)}</span>` : ""}
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          <button class="btn btn-sm btn-outline" onclick="toggleRuleItem(${idx})" title="启用/注释该条规则">
            ${item.enabled ? "已启用" : "已注释"}
          </button>
          <button class="btn btn-sm btn-danger" onclick="deleteRuleItem(${idx})" title="删除">✕</button>
        </div>
      </div>
    `;
  });

  if (!html) {
    html = `<div style="padding:24px;text-align:center;color:#64748b;font-size:12.5px;">未找到匹配的规则条目</div>`;
  }
  container.innerHTML = html;
  document.getElementById("ruleCountSummary").textContent = `当前共 ${activeCount} 条生效规则`;
}

function quickFillRule(ruleStr) {
  document.getElementById("inpNewRulePath").value = ruleStr;
}

function addNewRuleItem() {
  const inp = document.getElementById("inpNewRulePath");
  const val = (inp.value || "").trim();
  if (!val) {
    showToast("请输入有效的路径或通配符规则");
    return;
  }
  if (!val.startsWith("/")) {
    showToast("路径规则必须以 / 开头，例如 /data/media/0/...");
    return;
  }
  currentRuleLines.unshift({
    type: "rule",
    path: val,
    enabled: true,
    category: "WebUI自定义添加"
  });
  inp.value = "";
  document.getElementById("rawRuleTextarea").value = serializeRuleLines();
  renderVisualRuleList();
  showToast("已添加至列表顶部，请点击【保存修改】写入文件");
}

function toggleRuleItem(idx) {
  if (!currentRuleLines[idx]) return;
  currentRuleLines[idx].enabled = !currentRuleLines[idx].enabled;
  document.getElementById("rawRuleTextarea").value = serializeRuleLines();
  renderVisualRuleList();
}

function deleteRuleItem(idx) {
  currentRuleLines.splice(idx, 1);
  document.getElementById("rawRuleTextarea").value = serializeRuleLines();
  renderVisualRuleList();
}

async function saveCurrentRuleFile() {
  const content = isRawEditMode
    ? document.getElementById("rawRuleTextarea").value
    : serializeRuleLines();

  const path = FILE_PATHS[currentRuleType];
  const ok = await writeRootFile(path, content, "644");
  if (ok) {
    parseRuleTextToLines(content);
    renderVisualRuleList();
    showToast("名单配置已成功保存并生效！");
  } else {
    showToast("写入配置文件失败，请检查 Root 权限");
  }
}

// History & Logs Management
function switchHistoryView(view) {
  const isFiles = view === "files";
  document.getElementById("segHistFiles").classList.toggle("active", isFiles);
  document.getElementById("segRawClearLog").classList.toggle("active", !isFiles);
  document.getElementById("historyFilesPanel").style.display = isFiles ? "block" : "none";
  document.getElementById("rawClearLogPanel").style.display = isFiles ? "none" : "block";
}

function setHistoryFilter(filterType) {
  currentHistoryFilter = filterType;
  renderHistoryItems();
}

async function loadHistoryAndLogs() {
  if (isKsuEnv()) {
    const histRes = await execRootCmd(`tail -n 300 "${FILE_PATHS.history_log}" 2>/dev/null`);
    const logRes = await execRootCmd(`tail -n 200 "${FILE_PATHS.clear_log}" 2>/dev/null`);
    parseHistoryLog(histRes.stdout || "", logRes.stdout || "");
    document.getElementById("rawClearLogText").value = logRes.stdout || "暂无 Clear.log 日志内容";
  } else {
    const demoHist = [
      "2026-11-02 11:30:02 | 删除文件 | /data/media/0/Android/data/com.tencent.mm/cache/temp_48291.tmp",
      "2026-11-02 11:30:02 | 删除目录 | /data/media/0/2345手机助手/download_cache",
      "2026-11-02 11:30:01 | 删除文件 | /data/data/com.xiaomi.shop/app_bugly/crash_report.log",
      "2026-11-02 11:30:01 | MT清理 | /data/media/0/MT2/.recycle/bak_102.apk",
      "2026-11-02 00:00:03 | 删除目录 | /data/media/0/Tencent/tbs_live_log/x5_core_log"
    ].join("\n");
    parseHistoryLog(demoHist, "");
    document.getElementById("rawClearLogText").value =
      "2026-11-02 11:30:01 删除文件: /data/data/com.xiaomi.shop/app_bugly/crash_report.log\n2026-11-02 11:30:02 删除目录: /data/media/0/2345手机助手/download_cache\n2026-11-02 11:30:02 清理完成！已删除 64 个文件，12 个目录\n上一次清理时间: 2026-11-02 11:30:02";
  }
  renderHistoryItems();
}

function parseHistoryLog(histText, clearLogText) {
  const lines = (histText || "").trim().split("\n").filter(Boolean);
  historyEntries = [];

  lines.forEach((line) => {
    const parts = line.split("|").map((s) => s.trim());
    if (parts.length >= 3) {
      historyEntries.push({
        time: parts[0],
        type: parts[1],
        path: parts.slice(2).join(" | ")
      });
    }
  });

  // Fallback: also parse directly from Clear.log if History_Files.log is empty
  if (historyEntries.length === 0 && clearLogText) {
    clearLogText.split("\n").forEach((l) => {
      const m = l.match(/^([0-9-]+\s+[0-9:]+)\s+(删除文件|删除目录):?\s*(.+)$/);
      if (m) {
        historyEntries.push({
          time: m[1],
          type: m[2],
          path: m[3]
        });
      }
    });
  }
  historyEntries.reverse(); // Newest first
}

function renderHistoryItems() {
  const container = document.getElementById("historyListContainer");
  const kw = (document.getElementById("inpSearchHistory").value || "").trim().toLowerCase();

  const filtered = historyEntries.filter((item) => {
    if (currentHistoryFilter !== "ALL" && item.type !== currentHistoryFilter) return false;
    if (kw && !item.path.toLowerCase().includes(kw) && !item.time.toLowerCase().includes(kw)) return false;
    return true;
  });

  if (filtered.length === 0) {
    container.innerHTML = `<div style="padding:28px;text-align:center;color:#64748b;font-size:12.5px;">暂无符合条件的历史清理文件记录</div>`;
    return;
  }

  container.innerHTML = filtered
    .map((item) => {
      let tagClass = "tag-file";
      if (item.type === "删除目录") tagClass = "tag-dir";
      if (item.type === "MT清理") tagClass = "tag-mt";
      return `
        <div class="history-item">
          <div class="history-meta">
            <span class="tag ${tagClass}">${escapeHtml(item.type)}</span>
            <span>${escapeHtml(item.time)}</span>
          </div>
          <div class="history-path">${escapeHtml(item.path)}</div>
        </div>
      `;
    })
    .join("");
}

async function clearAllLogs() {
  if (isKsuEnv()) {
    await execRootCmd(`sh "${CTL_SCRIPT}" clear_logs`);
  }
  historyEntries = [];
  document.getElementById("rawClearLogText").value = "";
  renderHistoryItems();
  showToast("已清空历史清理明细与 Clear.log");
}

async function resetCumulativeStats() {
  if (isKsuEnv()) {
    await execRootCmd(`sh "${CTL_SCRIPT}" reset_stats`);
  }
  showToast("已重置累计清理文件与目录计数");
  refreshDashboard();
}

function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Initialize on DOMContentLoaded
window.addEventListener("DOMContentLoaded", () => {
  applyUiPrefs();
  initScheduleSelects();
  refreshDashboard();
});

// Appearance preferences (stored locally in WebView; independent from module engine)
const UI_PREFS_KEY = "autopurge_pro_ui_v220";
const uiPrefs = (() => {
  try { return Object.assign({theme:"dark", language:"zh", navMode:"traditional"}, JSON.parse(localStorage.getItem(UI_PREFS_KEY)||"{}")); }
  catch (_) { return {theme:"dark", language:"zh", navMode:"traditional"}; }
})();
function saveUiPrefs() {
  try { localStorage.setItem(UI_PREFS_KEY, JSON.stringify(uiPrefs)); } catch (_) {}
}
function setTheme(theme) {
  uiPrefs.theme = theme === "light" ? "light" : "dark";
  applyUiPrefs(); saveUiPrefs();
  showToast(uiPrefs.language === "en" ? "Theme updated" : "主题已切换");
}
function setLanguage(language) {
  uiPrefs.language = language === "en" ? "en" : "zh";
  applyUiPrefs(); saveUiPrefs();
  showToast(uiPrefs.language === "en" ? "Language updated" : "语言已切换");
}
function setNavMode(mode) {
  uiPrefs.navMode = mode === "floating" ? "floating" : "traditional";
  applyUiPrefs(); saveUiPrefs();
  showToast(uiPrefs.language === "en" ? "Navigation style updated" : "底栏样式已切换");
}
const UI_EN = {
  "概览看板":"Dashboard","黑白名单":"Rules","定时设置":"Schedule","清理历史":"History","设置":"Settings",
  "外观设置 / Appearance":"Appearance","主题模式":"Theme","切换深色或浅色界面":"Switch between dark and light themes",
  "深色":"Dark","浅色":"Light","界面语言":"Language","切换简体中文或英文":"Switch between Chinese and English","中文":"中文","底栏样式":"Navigation style",
  "选择固定传统底栏或悬浮胶囊底栏":"Choose a fixed or floating navigation bar","传统模式":"Traditional","悬浮模式":"Floating",
  "导航栏设置 / Navigation":"Navigation","关于模块 / About":"About","模块名称":"Module","当前版本":"Version","作者":"Author",
  "项目地址":"Project","GitHub 项目主页 ↗":"GitHub repository ↗",
  "智能存储清理管理面板":"Smart storage cleanup manager",
  "累计清理文件":"Files cleaned","累计清理目录":"Directories cleaned","累计释放空间":"Space freed",
  "最近清理时间":"Last cleanup","黑名单规则":"Blacklist rules","白名单保护":"Whitelist protection","MT清理规则":"MT cleanup rules",
  "立即执行全量清理":"Run full cleanup","仅执行 MT 清理":"Run MT cleanup",
  "双时段自定义定时设置":"Dual schedule","历史清理文件明细与运行日志":"Cleanup history & logs",
  "黑白名单与清理路径管理":"Rule & path management","保存修改":"Save changes","重新读取":"Reload",
  "外观、语言与导航偏好保存在当前 WebView 本地，不会修改清理规则或后台清理逻辑。":"Appearance, language and navigation preferences are stored locally in this WebView. Cleanup rules and background services are not changed.",
  "智能存储清理引擎":"Smart Storage Cleanup Engine","检测环境中...":"Detecting environment...","🟢 模块运行中":"🟢 Module Running",
  "后台守护与定时清理服务已激活动态监控":"Background services and scheduled cleanup are active","主控守护 (MainControl)":"Main Controller (MainControl)",
  "定时器 (crond)":"Scheduler (crond)","MT监测 (SmartClear)":"MT Monitor (SmartClear)","日志守护 (LogClear)":"Log Monitor (LogClear)",
  "💾 /data 存储空间与规则库概况":"💾 /data Storage & Rules Overview","⚙️ 核心子模块开关设置":"⚙️ Core Module Switches",
  "实时同步 配置.conf":"Synced with 配置.conf","定时自动清理 (timed_cleaning)":"Scheduled cleanup (timed_cleaning)",
  "按照设定的双时段 Cron 计划在后台自动执行黑名单清理":"Automatically clean blacklist paths using the dual-slot Cron schedule",
  "MT管理器联动清理 (mt_cleaning)":"MT Manager cleanup (mt_cleaning)","日志自动截断清理 (log_cleaning)":"Automatic log truncation (log_cleaning)",
  "日志文件清理阈值 (log_purge_size)":"Log cleanup threshold (log_purge_size)","🛡️ 黑白名单与清理路径管理":"🛡️ Blacklist, Whitelist & Paths",
  "黑名单 (清理项)":"Blacklist (cleanup)","白名单 (保护项)":"Whitelist (protected)","MT清理名单":"MT cleanup list","+ 添加规则":"+ Add rule",
  "共 0 条有效路径":"0 valid paths","⏰ 双时段自定义定时设置":"⏰ Dual-slot Schedule",
  "⚡ 快捷定时方案一键预设：":"⚡ Schedule presets:","每天 (*)":"Every day (*)","星期一 (1)":"Monday (1)","星期二 (2)":"Tuesday (2)",
  "星期三 (3)":"Wednesday (3)","星期四 (4)":"Thursday (4)","星期五 (5)":"Friday (5)","星期六 (6)":"Saturday (6)","星期日 (7)":"Sunday (7)",
  "💾 保存定时配置并立即生效":"💾 Save schedule and apply","📜 历史清理文件明细与运行日志":"📜 Cleanup History & Runtime Logs",
  "支持检索每一次被清理的文件与目录完整路径":"Search full paths of cleaned files and directories","全部记录":"All records",
  "仅看文件":"Files only","仅看目录":"Directories only","🗑️ 清空历史与日志":"🗑️ Clear history & logs","♻️ 重置累计统计计数":"♻️ Reset cumulative statistics"
};
function applyUiPrefs() {
  document.documentElement.dataset.theme = uiPrefs.theme;
  document.body.classList.toggle("nav-floating", uiPrefs.navMode === "floating");
  const nav = document.querySelector(".bottom-nav");
  if (nav) nav.classList.toggle("nav-floating", uiPrefs.navMode === "floating");
  ["themeDark","themeLight","langZh","langEn","navTraditional","navFloating"].forEach(id => {
    const el=document.getElementById(id); if(el) el.classList.remove("active");
  });
  const activeIds = {dark:"themeDark",light:"themeLight",zh:"langZh",en:"langEn",traditional:"navTraditional",floating:"navFloating"};
  ["theme","language","navMode"].forEach(k => { const el=document.getElementById(activeIds[uiPrefs[k]]); if(el) el.classList.add("active"); });
  document.documentElement.lang = uiPrefs.language === "en" ? "en" : "zh-CN";
  document.title = uiPrefs.language === "en" ? "AutoPurge Pro - Settings" : "AutoPurge Pro WebUI - by liancan";
  // Translate exact static text nodes while preserving element structure and handlers.
  const reverseMap = Object.fromEntries(Object.entries(UI_EN).map(([zh,en]) => [en,zh]));
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    const raw = node.nodeValue, trimmed = raw.trim();
    if (!trimmed) continue;
    const translated = uiPrefs.language === "en" ? UI_EN[trimmed] : reverseMap[trimmed];
    if (translated) node.nodeValue = raw.replace(trimmed, translated);
  }
}

