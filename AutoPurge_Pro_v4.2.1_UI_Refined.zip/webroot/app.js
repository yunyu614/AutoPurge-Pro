/**
 * AutoPurge Pro WebUI Frontend Controller
 * Author: liancan
 * Supports KernelSU / KernelSU Next / APatch / MMRL WebView Bridge + Preview Sandbox
 */

const MODDIR = "/data/adb/modules/Clear_Rubbish";
const CONFIG_DIR = "/data/media/0/Android/Clear/清理垃圾";
const CTL_SCRIPT = `${MODDIR}/bin/autopurge_ctl.sh`;

const FILE_PATHS = {
  blacklist: `${CONFIG_DIR}/名单配置/黑名单.conf`,
  whitelist: `${CONFIG_DIR}/名单配置/白名单.conf`,
  mtlist: `${CONFIG_DIR}/名单配置/MT.conf`,
  main_conf: `${CONFIG_DIR}/配置.conf`,
  timing_conf: `${CONFIG_DIR}/自定义定时设置/定时设置.conf`,
  timing_sh: `${CONFIG_DIR}/自定义定时设置/Timing_Settings.sh`,
  clear_log: `${CONFIG_DIR}/Clear.log`,
  history_log: `${CONFIG_DIR}/History_Files.log`,
  file_paths: `${CONFIG_DIR}/FilePaths.conf`
};

// State
let currentRuleType = "blacklist";
let isRawEditMode = false;
let currentRuleLines = [];
let rawRuleContentCache = {
  blacklist: "# 应用缓存\n/data/data/*/cache/*\n/data/media/0/Android/data/*/cache/*\n# 2345残留垃圾目录\n/data/media/0/2345*\n/data/media/0/Android/data/com.market2345/cache/*",
  whitelist: "# 白名单保护路径\n/sdcard/*\n/data/adb/*\n/data/media/0/DCIM/\n/data/media/0/Pictures/\n/data/media/0/Download/",
  mtlist: "/data/media/0/.*\n/data/media/0/QQBrowser/\n/data/media/0/MT2/.recycle/\n/data/media/0/ramdump/"
};
let historyEntries = [];
let currentHistoryFilter = "ALL";

// Native KernelSU WebView Bridge Wrapper
let cbCounter = 0;
function isKsuEnv() {
  return typeof window.ksu !== "undefined" && typeof window.ksu.exec === "function";
}

let rootExecQueue = Promise.resolve();
function execRootCmdDirect(command, timeoutMs = 12000) {
  return new Promise((resolve) => {
    if (!isKsuEnv()) { resolve({ errno: 0, stdout: "", stderr: "" }); return; }
    const cbName = `ksu_cb_${Date.now()}_${++cbCounter}`;
    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try { delete window[cbName]; } catch (_) {}
      resolve(result);
    };
    const timer = setTimeout(() => finish({ errno: 124, stdout: "", stderr: `Root 命令等待超时（${Math.round(timeoutMs/1000)} 秒），请检查 Root WebUI 桥接或后台命令` }), timeoutMs);
    window[cbName] = (errno, stdout, stderr) => finish({ errno: Number(errno), stdout: stdout || "", stderr: stderr || "" });
    try { window.ksu.exec(command, JSON.stringify({}), cbName); }
    catch (e) { finish({ errno: 1, stdout: "", stderr: String(e) }); }
  });
}
// Serialize bridge calls: some Root WebView bridges become unstable when several
// shell commands are dispatched concurrently during page changes or fast taps.
function execRootCmd(command, timeoutMs = 12000) {
  const run = () => execRootCmdDirect(command, timeoutMs);
  const result = rootExecQueue.then(run, run);
  rootExecQueue = result.then(() => undefined, () => undefined);
  return result;
}

function showToast(msg) {
  if (isKsuEnv() && typeof window.ksu.toast === "function") {
    window.ksu.toast(msg);
  }
  const box = document.getElementById("toastBox");
  if (!box) return;
  box.textContent = msg;
  box.classList.add("show");
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => box.classList.remove("show"), 2400);
}

// Base64 UTF-8 safe helpers for writing config files via shell without escaping issues
function utf8ToB64(str) {
  return window.btoa(unescape(encodeURIComponent(str)));
}

async function readRootFile(path) {
  if (!isKsuEnv()) {
    return rawRuleContentCache[currentRuleType] || "";
  }
  const { errno, stdout } = await execRootCmd(`cat "${path}" 2>/dev/null`);
  return errno === 0 ? stdout : "";
}

async function writeRootFile(path, content, mode = "644") {
  if (!isKsuEnv()) {
    rawRuleContentCache[currentRuleType] = content;
    return true;
  }
  const b64 = utf8ToB64(content);
  const cmd = `echo "${b64}" | base64 -d > "${path}.tmp" && chmod ${mode} "${path}.tmp" && mv -f "${path}.tmp" "${path}"`;
  const { errno } = await execRootCmd(cmd);
  return errno === 0;
}

function formatSizeFromKB(kb) {
  const num = Number(kb) || 0;
  if (num >= 1048576) {
    return (num / 1048576).toFixed(2) + " GB";
  }
  if (num >= 1024) {
    return (num / 1024).toFixed(1) + " MB";
  }
  return num + " KB";
}

// Tab Navigation
let tabLoadToken = 0;
function switchTab(tabId) {
  if (tabId === "files") tabId = "clean"; // legacy links now open the unified page
  document.querySelectorAll(".tab-pane").forEach((el) => el.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach((el) => el.classList.remove("active"));
  const targetPane = document.getElementById(`tab-${tabId}`);
  const targetNav = document.getElementById(`nav-${tabId}`);
  if (targetPane) targetPane.classList.add("active");
  if (targetNav) targetNav.classList.add("active");
  const token = ++tabLoadToken;
  const tasks = tabId === "dashboard" || tabId === "clean" ? [refreshDashboard()] :
    tabId === "rules" ? [reloadCurrentRuleFile(), loadFilePaths()] : tabId === "settings" ? [loadSimpleSchedule()] : tabId === "logs" ? [loadFeatureLogs()] : [];
  if (tasks.length) Promise.allSettled(tasks).then((results) => {
    if (token !== tabLoadToken) return;
    const failed = results.some(x => x.status === "rejected");
    if (failed) showToast("页面数据读取未完成，可稍后点击刷新；界面仍可继续操作");
  });
}

// Simplified daily schedule: one fixed time, loaded from the persisted config.
function initScheduleSelects() {
  const h = document.getElementById("dailyHour");
  const m = document.getElementById("dailyMinute");
  if (!h || !m) return;
  h.innerHTML = Array.from({length:24}, (_,i)=>`<option value="${i}">${String(i).padStart(2,"0")}</option>`).join("");
  m.innerHTML = Array.from({length:60}, (_,i)=>`<option value="${i}">${String(i).padStart(2,"0")}</option>`).join("");
  h.value = "3"; m.value = "0";
  updateSimpleSchedulePreview();
  h.addEventListener("change", updateSimpleSchedulePreview);
  m.addEventListener("change", updateSimpleSchedulePreview);
  loadSimpleSchedule();
}
function updateSimpleSchedulePreview() {
  const h=document.getElementById("dailyHour"), m=document.getElementById("dailyMinute"), out=document.getElementById("scheduleSummary");
  if(h && m && out) out.textContent=`每天 ${String(h.value).padStart(2,"0")}:${String(m.value).padStart(2,"0")} 自动清理`;
}
async function loadSimpleSchedule() {
  if (!isKsuEnv()) return;
  const content=await readRootFile(FILE_PATHS.timing_conf);
  const hour=(content.match(/^Set_Time1=(.*)$/m)||[])[1] || "3";
  const minute=(content.match(/^Set_minute1=(.*)$/m)||[])[1] || "0";
  const h=document.getElementById("dailyHour"), m=document.getElementById("dailyMinute");
  if(h) h.value=/^(?:[0-9]|1[0-9]|2[0-3])$/.test(hour.trim())?String(Number(hour)): "3";
  if(m) m.value=/^(?:[0-9]|[1-5][0-9])$/.test(minute.trim())?String(Number(minute)): "0";
  updateSimpleSchedulePreview();
}
async function saveSimpleSchedule() {
  const hourEl = document.getElementById("dailyHour");
  const minuteEl = document.getElementById("dailyMinute");
  if (!hourEl || !minuteEl) return;
  const h = Number(hourEl.value);
  const m = Number(minuteEl.value);
  if (!Number.isInteger(h) || h < 0 || h > 23 || !Number.isInteger(m) || m < 0 || m > 59) {
    showToast("时间无效，请重新选择");
    return;
  }
  const mm = String(m).padStart(2, "0");
  const content = `# AutoPurge Pro daily schedule\nSet_Time1=${h}\nSet_minute1=${mm}\nSet_weekday1=*\n# Legacy compatibility\nSet_Time2=${h}\nSet_minute2=${mm}\nSet_weekday2=*\n`;
  const ok = await writeRootFile(FILE_PATHS.timing_conf, content, "644");
  if (!ok) {
    showToast("定时配置写入失败，请检查 Root 权限");
    return;
  }
  if (!isKsuEnv()) {
    showToast("定时配置已保存（预览模式）");
    updateSimpleSchedulePreview();
    return;
  }

  const res = await execRootCmd(`sh "${FILE_PATHS.timing_sh}"`);
  const output = `${res.stdout || ""}\n${res.stderr || ""}`.trim();
  if (res.errno !== 0 || /错误：|启动后立即退出|未找到包含/.test(output)) {
    showToast(output || "定时配置已保存，但定时服务启动失败");
    await refreshDashboard();
    return;
  }
  if (/后台任务未启动/.test(output)) {
    showToast("配置已保存；定时开关处于关闭状态");
  } else {
    const statusRes = await execRootCmd(`sh "${CTL_SCRIPT}" status`);
    let running = false;
    try {
      const status = JSON.parse((statusRes.stdout || "").trim().split("\n").pop());
      running = status?.daemons?.crond === true;
    } catch (_) {}
    showToast(running ? `定时服务运行已确认：每天 ${String(h).padStart(2, "0")}:${mm}` : "Cron 配置已保存，但服务运行状态尚未确认");
  }
  updateSimpleSchedulePreview();
  await refreshDashboard();
}

// Dashboard Data Loading
async function refreshDashboard() {
  if (isKsuEnv()) {
    const { errno, stdout } = await execRootCmd(`sh "${CTL_SCRIPT}" status`);
    if (errno === 0 && stdout) {
      try {
        const data = JSON.parse(stdout);
        renderDashboardData(data);
        return;
      } catch (e) {
        console.error("Failed to parse status JSON:", e);
      }
    }
  } else {
    renderDashboardData({
      config: {
        master_switch: true,
        timed_cleaning: true,
        mt_cleaning: true,
        log_cleaning: true,
        log_purge_size: "2M"
      },
      schedule: { t1: "0", m1: "00", w1: "*", t2: "12", m2: "00", w2: "*" },
      stats: {
        total_files: 1842,
        total_dirs: 316,
        total_runs: 28,
        total_freed_kb: 1482940,
        last_run_files: 64,
        last_run_dirs: 12,
        last_clean_time: "2026-11-02 11:30:00",
        bl_count: 492,
        wl_count: 18,
        mt_count: 31,
        log_size_bytes: 18432
      },
      daemons: { main_control: true, smart_clear: true, log_clear: true, crond: true },
      storage: { total_kb: 251658240, used_kb: 118489088, avail_kb: 133169152 }
    });
  }
}

function renderDashboardData(data) {
  const cfg = data.config || {};
  const st = data.stats || {};
  const dm = data.daemons || {};
  const sc = data.schedule || {};
  const disk = data.storage || {};

  // Master switch UI
  const masterOn = cfg.master_switch !== false;
  const masterSwitch = document.getElementById("swMaster");
  if (masterSwitch) masterSwitch.checked = masterOn;
  document.getElementById("masterStatusTitle").textContent = masterOn ? "🟢 模块运行中" : "⏸️ 模块已暂停";
  document.getElementById("masterStatusDesc").textContent = masterOn
    ? "自动服务运行正常"
    : "后台自动任务已暂停";

  // Sub-switches
  const swCleanupMaster = document.getElementById("swCleanupMaster"); if (swCleanupMaster) swCleanupMaster.checked = [cfg.blacklist_cleaning, cfg.mt_cleaning, cfg.log_cleaning, cfg.module_residue_cleaning, cfg.apk_cleaning, cfg.timed_cleaning].every(v => v !== false);
  const swOrganizeMaster = document.getElementById("swOrganizeMaster"); if (swOrganizeMaster) swOrganizeMaster.checked = cfg.file_organize === true;
  const swTimed = document.getElementById("swTimed"); if (swTimed) swTimed.checked = cfg.timed_cleaning !== false;
  const swMt = document.getElementById("swMt"); if (swMt) swMt.checked = cfg.mt_cleaning !== false;
  const swLog = document.getElementById("swLog"); if (swLog) swLog.checked = cfg.log_cleaning !== false;
  const selLogSize = document.getElementById("selLogSize"); if (selLogSize && cfg.log_purge_size) selLogSize.value = cfg.log_purge_size;
  const swBlacklist = document.getElementById("swBlacklistClean"); if (swBlacklist) swBlacklist.checked = cfg.blacklist_cleaning !== false;
  const elApk = document.getElementById("swApkClean");
  if (elApk) elApk.checked = cfg.apk_cleaning === true;
  const elMod = document.getElementById("swModResidue");
  if (elMod) elMod.checked = cfg.module_residue_cleaning === true;
  const elOrg = document.getElementById("swFileOrganize");
  if (elOrg) elOrg.checked = cfg.file_organize === true;

  // Daemons
  setDot("dotMain", dm.main_control);
  setDot("dotCron", dm.crond);
  setDot("dotSmart", dm.smart_clear);
  setDot("dotLog", dm.log_clear);

  // Stats
  document.getElementById("statTotalFiles").textContent = Number(st.total_files || 0).toLocaleString();
  document.getElementById("statTotalDirs").textContent = Number(st.total_dirs || 0).toLocaleString();
  document.getElementById("statLastFiles").textContent = `上次清理: +${st.last_run_files || 0} 个文件`;
  document.getElementById("statLastDirs").textContent = `上次清理: +${st.last_run_dirs || 0} 个目录`;
  document.getElementById("statTotalFreed").textContent = formatSizeFromKB(st.total_freed_kb || 0);
  document.getElementById("statTotalRuns").textContent = `累计执行: ${st.total_runs || 0} 次`;
  document.getElementById("statLastTime").textContent = st.last_clean_time || "尚未执行";

  const pad2 = (v) => (v === "*" ? "*" : String(v).padStart(2, "0"));
  document.getElementById("statCronSummary").textContent = `每日定时: ${String(sc.t1 || "3").padStart(2,"0")}:${String(sc.m1 || "00").padStart(2,"0")}`;

  // Badges & Log size
  document.getElementById("badgeBlCount").textContent = st.bl_count || 0;
  document.getElementById("badgeWlCount").textContent = st.wl_count || 0;
  document.getElementById("badgeMtCount").textContent = st.mt_count || 0;
  const logSizeDesc=document.getElementById("curLogSizeDesc"); if(logSizeDesc) logSizeDesc.textContent = `当前 Clear.log 大小: ${(Number(st.log_size_bytes || 0) / 1024).toFixed(1)} KB`;

  // Storage bar
  if (disk.total_kb > 0) {
    const pct = Math.min(100, Math.round((disk.used_kb / disk.total_kb) * 100));
    document.getElementById("storageBarFill").style.width = `${pct}%`;
    document.getElementById("storagePercentText").textContent = `已用 ${pct}%`;
    document.getElementById("storageUsedText").textContent = `已用: ${(disk.used_kb / 1048576).toFixed(1)} GB`;
    document.getElementById("storageAvailText").textContent = `可用: ${(disk.avail_kb / 1048576).toFixed(1)} GB`;
  }

  if (typeof applyUiPrefs === "function") applyUiPrefs();
}

function setDot(id, isOn) {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = "dot " + (isOn ? "on" : "off");
}

// Switch & Config Handlers
async function onCleanupMasterToggle(checked) {
  const keys = ["blacklist_cleaning", "mt_cleaning", "log_cleaning", "module_residue_cleaning", "apk_cleaning", "timed_cleaning"];
  const ids = ["swBlacklistClean", "swMt", "swLog", "swModResidue", "swApkClean", "swTimed"];
  ids.forEach(id => { const el = document.getElementById(id); if (el) el.checked = checked; });
  if (!isKsuEnv()) { showToast(`清理功能总开关已${checked ? "开启" : "关闭"}（预览模式）`); return; }
  const assignments = keys.map(key => `if grep -qE "^[[:space:]]*${key}[[:space:]]*=" "${FILE_PATHS.main_conf}"; then sed -i "s|^[[:space:]]*${key}[[:space:]]*=.*|${key}=${checked}|g" "${FILE_PATHS.main_conf}"; else echo "${key}=${checked}" >> "${FILE_PATHS.main_conf}"; fi`).join("; ");
  const result = await execRootCmd(`${assignments}; sh "${CTL_SCRIPT}" apply`);
  if (result.errno !== 0) { showToast("清理总开关保存失败，请检查 Root 权限"); refreshDashboard(); return; }
  showToast(`清理功能及定时任务已${checked ? "全部启用" : "全部停用"}`);
  refreshDashboard();
}

async function onToggleSwitch(key, checked) {
  const val = checked ? "true" : "false";
  if (isKsuEnv()) {
    const cmd = `
      if grep -qE "^[[:space:]]*${key}[[:space:]]*=" "${FILE_PATHS.main_conf}"; then
        sed -i "s|^[[:space:]]*${key}[[:space:]]*=.*|${key}=${val}|g" "${FILE_PATHS.main_conf}"
      else
        echo "${key}=${val}" >> "${FILE_PATHS.main_conf}"
      fi
      sh "${CTL_SCRIPT}" apply
    `;
    await execRootCmd(cmd);
    showToast(`已${checked ? "开启" : "关闭"} ${key}`);
    refreshDashboard();
  } else {
    showToast(`已${checked ? "开启" : "关闭"} ${key} (预览模式)`);
  }
}

async function onChangeLogSize(val) {
  const allowed = ["512K", "1M", "2M", "5M", "10M"];
  if (!allowed.includes(val)) {
    showToast("无效的日志清理阈值");
    return;
  }
  if (isKsuEnv()) {
    const cmd = `
      if grep -qE "^[[:space:]]*log_purge_size[[:space:]]*=" "${FILE_PATHS.main_conf}"; then
        sed -i "s|^[[:space:]]*log_purge_size[[:space:]]*=.*|log_purge_size=${val}|g" "${FILE_PATHS.main_conf}"
      else
        echo "log_purge_size=${val}" >> "${FILE_PATHS.main_conf}"
      fi
      pkill -f "${MODDIR}/bin/LogClear" 2>/dev/null
      sh "${CTL_SCRIPT}" apply
    `;
    const result = await execRootCmd(cmd);
    if (result.errno !== 0) {
      showToast("日志阈值保存失败，请检查 Root 权限");
      return;
    }
    showToast(`日志清理阈值已设为 ${val}`);
  } else {
    showToast(`日志清理阈值已设为 ${val} (预览模式)`);
  }
}

async function triggerCleanup(mode) {
  const btnId = mode === "mt" ? "btnCleanMT" : "btnCleanAll";
  const btn = document.getElementById(btnId);
  if (!btn || btn.disabled) return;
  const origText = btn.textContent;
  btn.disabled = true;
  btn.textContent = "⏳ 正在启动清理...";

  try {
    if (!isKsuEnv()) {
      await new Promise((r) => setTimeout(r, 600));
      showToast("清理完成！已删除 23 个文件，5 个目录 (预览)");
      return;
    }

    const startRes = await execRootCmd(`sh "${CTL_SCRIPT}" start_clean ${mode}`);
    let startInfo = {};
    try { startInfo = JSON.parse((startRes.stdout || "{}").trim().split("\n").pop()); } catch (_) {}
    if (startRes.errno !== 0 || !["started", "already_running"].includes(startInfo.status)) {
      throw new Error(startRes.stderr || "无法启动清理任务");
    }
    showToast(startInfo.status === "already_running" ? "已有清理任务正在执行，请稍候" : "清理任务已在后台启动，界面可继续操作");
    btn.textContent = "⏳ 后台清理中...";

    const startedAt = Date.now();
    let finished = false;
    while (!finished && Date.now() - startedAt < 30 * 60 * 1000) {
      await new Promise((r) => setTimeout(r, 1800));
      const statusRes = await execRootCmd(`sh "${CTL_SCRIPT}" clean_status`);
      let status = {};
      try { status = JSON.parse((statusRes.stdout || "{}").trim().split("\n").pop()); } catch (_) {}
      if (status.status === "done") {
        finished = true;
        showToast(status.success ? "清理已完成" : "清理任务结束，请查看运行日志");
        break;
      }
      if (status.status === "idle") {
        finished = true;
        showToast("清理任务状态已结束，请刷新统计或查看日志");
      }
    }
    if (!finished) showToast("清理仍在后台运行，可稍后查看清理记录");
    await refreshDashboard();
  } catch (e) {
    showToast(`清理启动失败：${String(e.message || e).slice(0, 80)}`);
  } finally {
    btn.disabled = false;
    btn.textContent = origText;
  }
}

// Rules Management (Blacklist / Whitelist / MT.conf)
function switchRuleType(type) {
  currentRuleType = type;
  document.getElementById("segBtnBlacklist").classList.toggle("active", type === "blacklist");
  document.getElementById("segBtnWhitelist").classList.toggle("active", type === "whitelist");
  document.getElementById("segBtnMtlist").classList.toggle("active", type === "mtlist");
  document.getElementById("currentRuleFilePath").textContent = FILE_PATHS[type];
  reloadCurrentRuleFile();
}

function toggleRuleEditMode() {
  isRawEditMode = !isRawEditMode;
  document.getElementById("visualRuleView").style.display = isRawEditMode ? "none" : "block";
  document.getElementById("rawRuleView").style.display = isRawEditMode ? "block" : "none";
  document.getElementById("btnToggleEditMode").textContent = isRawEditMode ? "📋 切换列表模式" : "📝 切换源码模式";

  if (isRawEditMode) {
    document.getElementById("rawRuleTextarea").value = serializeRuleLines();
  } else {
    parseRuleTextToLines(document.getElementById("rawRuleTextarea").value);
    renderVisualRuleList();
  }
}

async function reloadCurrentRuleFile() {
  const path = FILE_PATHS[currentRuleType];
  const content = await readRootFile(path);
  document.getElementById("rawRuleTextarea").value = content;
  parseRuleTextToLines(content);
  renderVisualRuleList();
}

function parseRuleTextToLines(text) {
  const rawLines = (text || "").replace(/\r/g, "").split("\n");
  currentRuleLines = [];
  let pendingCategory = "";

  for (let i = 0; i < rawLines.length; i++) {
    const trimmed = rawLines[i].trim();
    if (!trimmed) {
      currentRuleLines.push({ type: "empty", raw: "" });
      continue;
    }
    // Check if it is a commented out path like #/data/...
    if (/^#\s*\//.test(trimmed)) {
      const cleanPath = trimmed.replace(/^#\s*/, "");
      currentRuleLines.push({
        type: "rule",
        path: cleanPath,
        enabled: false,
        category: pendingCategory
      });
    } else if (trimmed.startsWith("#")) {
      pendingCategory = trimmed.replace(/^#+\s*/, "");
      currentRuleLines.push({ type: "comment", text: trimmed });
    } else {
      currentRuleLines.push({
        type: "rule",
        path: trimmed,
        enabled: true,
        category: pendingCategory
      });
    }
  }
}

function serializeRuleLines() {
  return currentRuleLines
    .map((item) => {
      if (item.type === "empty") return "";
      if (item.type === "comment") return item.text;
      return item.enabled ? item.path : `#${item.path}`;
    })
    .join("\n");
}

function getRuleAppGroup(path) {
  const patterns=[/\/data\/data\/([^/]+)\//,/\/Android\/data\/([^/]+)\//,/\/Android\/media\/([^/]+)\//,/\/Android\/obb\/([^/]+)\//];
  for(const re of patterns){const m=path.match(re);if(m)return m[1];}
  return "其他路径";
}
function renderVisualRuleList() {
  const container=document.getElementById("visualRuleList");
  const keyword=(document.getElementById("inpSearchRule")?.value||"").trim().toLowerCase();
  const groups=new Map(); let activeCount=0;
  currentRuleLines.forEach((item,idx)=>{
    if(item.type!=="rule")return;
    if(item.enabled)activeCount++;
    const app=getRuleAppGroup(item.path);
    if(!groups.has(app))groups.set(app,[]);
    groups.get(app).push({item,idx});
  });
  let html="";
  for(const [app,items] of groups){
    const visible=items.filter(({item})=>!keyword||item.path.toLowerCase().includes(keyword)||app.toLowerCase().includes(keyword)||(item.category||"").toLowerCase().includes(keyword));
    if(!visible.length)continue;
    const enabled=visible.filter(x=>x.item.enabled).length;
    html+=`<details class="rule-app-group" ${keyword?"open":""}>
      <summary class="rule-app-summary"><span class="rule-app-name">${escapeHtml(app)}</span><span class="rule-app-meta">${enabled}/${visible.length} 启用</span><span class="rule-app-chevron">⌄</span></summary>
      <div class="rule-app-paths">${visible.map(({item,idx})=>`
        <div class="rule-row ${item.enabled?"":"commented"}">
          <div style="flex:1;min-width:0;"><div class="rule-path">${escapeHtml(item.path)}</div>${item.category?`<span class="rule-note">${escapeHtml(item.category)}</span>`:""}</div>
          <div style="display:flex;align-items:center;gap:6px;"><button class="btn btn-sm btn-outline" onclick="toggleRuleItem(${idx})">${item.enabled?"已启用":"已停用"}</button><button class="btn btn-sm btn-danger" onclick="deleteRuleItem(${idx})">✕</button></div>
        </div>`).join("")}</div>
    </details>`;
  }
  if(!html)html=`<div style="padding:28px;text-align:center;color:#64748b;font-size:12.5px;">暂无符合条件的规则</div>`;
  container.innerHTML=html;
  const summary=document.getElementById("ruleCountSummary");
  if(summary)summary.textContent=`共 ${currentRuleLines.filter(x=>x.type==="rule").length} 条路径，${activeCount} 条启用 · 按应用归类`;
}

function addNewRuleItem() {
  const inp = document.getElementById("inpNewRulePath");
  const val = (inp.value || "").trim();
  if (!val) {
    showToast("请输入有效的路径或通配符规则");
    return;
  }
  if (!val.startsWith("/")) {
    showToast("路径规则必须以 / 开头，例如 /data/media/0/...");
    return;
  }
  currentRuleLines.unshift({
    type: "rule",
    path: val,
    enabled: true,
    category: "WebUI自定义添加"
  });
  inp.value = "";
  document.getElementById("rawRuleTextarea").value = serializeRuleLines();
  renderVisualRuleList();
  showToast("已添加至列表顶部，请点击【保存修改】写入文件");
}

function toggleRuleItem(idx) {
  if (!currentRuleLines[idx]) return;
  currentRuleLines[idx].enabled = !currentRuleLines[idx].enabled;
  document.getElementById("rawRuleTextarea").value = serializeRuleLines();
  renderVisualRuleList();
}

function deleteRuleItem(idx) {
  currentRuleLines.splice(idx, 1);
  document.getElementById("rawRuleTextarea").value = serializeRuleLines();
  renderVisualRuleList();
}

async function saveCurrentRuleFile() {
  const content = isRawEditMode
    ? document.getElementById("rawRuleTextarea").value
    : serializeRuleLines();

  const path = FILE_PATHS[currentRuleType];
  const ok = await writeRootFile(path, content, "644");
  if (ok) {
    parseRuleTextToLines(content);
    renderVisualRuleList();
    showToast("名单配置已成功保存并生效！");
  } else {
    showToast("写入配置文件失败，请检查 Root 权限");
  }
}

// History & Logs Management
async function clearAllLogs() {
  if (!window.confirm("确定清空所有功能日志与操作记录吗？此操作不可撤销。")) return;
  if (isKsuEnv()) {
    const res = await execRootCmd(`sh "${CTL_SCRIPT}" clear_logs`);
    if (res.errno !== 0) { showToast("日志清空失败，请检查 Root 权限"); return; }
  }
  const out=document.getElementById("featureLogView"); if(out) out.textContent="日志已清空。";
  showToast("功能日志已清空");
}

function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Initialize on DOMContentLoaded
window.addEventListener("DOMContentLoaded", () => {
  applyUiPrefs();
  initScheduleSelects();
  refreshDashboard();
});

// Appearance preferences (stored locally in WebView; independent from module engine)
const UI_PREFS_KEY = "autopurge_pro_ui_v400";
const LEGACY_UI_PREFS_KEY = "autopurge_pro_ui_v300";
const uiPrefs = (() => {
  try {
    const saved = localStorage.getItem(UI_PREFS_KEY) || localStorage.getItem(LEGACY_UI_PREFS_KEY) || "{}";
    return Object.assign({theme:"auto", palette:"blue", language:"zh", navMode:"floating"}, JSON.parse(saved));
  } catch (_) { return {theme:"auto", palette:"blue", language:"zh", navMode:"floating"}; }
})();
function saveUiPrefs() {
  try { localStorage.setItem(UI_PREFS_KEY, JSON.stringify(uiPrefs)); return true; }
  catch (_) { showToast("个性化设置保存失败，可能是 WebView 存储空间不足"); return false; }
}
function setTheme(theme) {
  uiPrefs.theme = ["auto", "light", "dark"].includes(theme) ? theme : "auto";
  applyUiPrefs(); saveUiPrefs();
  showToast(uiPrefs.language === "en" ? "Theme updated" : "主题模式已切换");
}
function setPalette(palette) {
  uiPrefs.palette = ["blue", "sage", "lilac", "rose", "sand"].includes(palette) ? palette : "blue";
  applyUiPrefs(); saveUiPrefs();
  showToast("莫奈配色已更新");
}
function setLanguage(language) {
  uiPrefs.language = language === "en" ? "en" : "zh";
  applyUiPrefs(); saveUiPrefs();
  showToast(uiPrefs.language === "en" ? "Language updated" : "语言已切换");
}
function setNavMode(mode) {
  uiPrefs.navMode = mode === "floating" ? "floating" : "traditional";
  applyUiPrefs(); saveUiPrefs();
  showToast(uiPrefs.language === "en" ? "Navigation style updated" : "底栏样式已切换");
}

const UI_EN = {
  "概览看板":"Dashboard","黑白名单":"Rules & Schedule","清理历史":"History","设置":"Settings",
  "外观设置 / Appearance":"Appearance","主题模式":"Theme","切换深色或浅色界面":"Switch between dark and light themes",
  "深色":"Dark","浅色":"Light","界面语言":"Language","切换简体中文或英文":"Switch between Chinese and English","中文":"中文","底栏样式":"Navigation style",
  "选择固定传统底栏或悬浮胶囊底栏":"Choose a fixed or floating navigation bar","传统模式":"Traditional","悬浮模式":"Floating",
  "导航栏设置 / Navigation":"Navigation","关于模块 / About":"About","模块名称":"Module","当前版本":"Version","作者":"Author",
  "项目地址":"Project","GitHub 项目主页 ↗":"GitHub repository ↗",
  "智能存储清理管理面板":"Smart storage cleanup manager",
  "累计清理文件":"Files cleaned","累计清理目录":"Directories cleaned","累计释放空间":"Space freed",
  "最近清理时间":"Last cleanup","黑名单规则":"Blacklist rules","白名单保护":"Whitelist protection","MT清理规则":"MT cleanup rules",
  "立即执行全量清理":"Run full cleanup","仅执行 MT 清理":"Run MT cleanup",
  "双时段自定义定时设置":"Dual schedule","历史清理文件明细与运行日志":"Cleanup history & logs",
  "黑白名单与清理路径管理":"Rule & path management","保存修改":"Save changes","重新读取":"Reload",
  "外观、语言与导航偏好保存在当前 WebView 本地，不会修改清理规则或后台清理逻辑。":"Appearance, language and navigation preferences are stored locally in this WebView. Cleanup rules and background services are not changed.",
  "智能存储清理引擎":"Smart Storage Cleanup Engine","检测环境中...":"Detecting environment...","🟢 模块运行中":"🟢 Module Running",
  "后台守护与定时清理服务已激活动态监控":"Background services and scheduled cleanup are active","主控守护 (MainControl)":"Main Controller (MainControl)",
  "定时器 (crond)":"Scheduler (crond)","MT监测 (SmartClear)":"MT Monitor (SmartClear)","日志守护 (LogClear)":"Log Monitor (LogClear)",
  "💾 /data 存储空间与规则库概况":"💾 /data Storage & Rules Overview","⚙️ 核心子模块开关设置":"⚙️ Core Module Switches",
  "实时同步 配置.conf":"Synced with 配置.conf","定时自动清理 (timed_cleaning)":"Scheduled cleanup (timed_cleaning)",
  "按照设定的双时段 Cron 计划在后台自动执行黑名单清理":"Automatically clean blacklist paths using the dual-slot Cron schedule",
  "MT管理器联动清理 (mt_cleaning)":"MT Manager cleanup (mt_cleaning)","日志自动截断清理 (log_cleaning)":"Automatic log truncation (log_cleaning)",
  "日志文件清理阈值 (log_purge_size)":"Log cleanup threshold (log_purge_size)","🛡️ 黑白名单与清理路径管理":"🛡️ Blacklist, Whitelist & Paths",
  "黑名单 (清理项)":"Blacklist (cleanup)","白名单 (保护项)":"Whitelist (protected)","MT清理名单":"MT cleanup list","+ 添加规则":"+ Add rule",
  "共 0 条有效路径":"0 valid paths","⏰ 双时段自定义定时设置":"⏰ Dual-slot Schedule",
  "⚡ 快捷定时方案一键预设：":"⚡ Schedule presets:","每天 (*)":"Every day (*)","星期一 (1)":"Monday (1)","星期二 (2)":"Tuesday (2)",
  "星期三 (3)":"Wednesday (3)","星期四 (4)":"Thursday (4)","星期五 (5)":"Friday (5)","星期六 (6)":"Saturday (6)","星期日 (7)":"Sunday (7)",
  "💾 保存定时配置并立即生效":"💾 Save schedule and apply","📜 历史清理文件明细与运行日志":"📜 Cleanup History & Runtime Logs",
  "支持检索每一次被清理的文件与目录完整路径":"Search full paths of cleaned files and directories","全部记录":"All records",
  "仅看文件":"Files only","仅看目录":"Directories only","🗑️ 清空历史与日志":"🗑️ Clear history & logs","♻️ 重置累计统计计数":"♻️ Reset cumulative statistics"
};
function applyUiPrefs() {
  const root = document.documentElement;
  const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
  root.dataset.theme = uiPrefs.theme === "auto" ? (prefersDark ? "dark" : "light") : uiPrefs.theme;
  root.dataset.palette = uiPrefs.palette || "blue";
  if (window.__autopurgeThemeListener) {
    try { window.matchMedia("(prefers-color-scheme: dark)").removeEventListener("change", window.__autopurgeThemeListener); } catch (_) {}
  }
  window.__autopurgeThemeListener = () => { if (uiPrefs.theme === "auto") applyUiPrefs(); };
  try { window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", window.__autopurgeThemeListener); } catch (_) {}
  document.body.classList.toggle("nav-floating", uiPrefs.navMode === "floating");
  const nav = document.querySelector(".bottom-nav");
  if (nav) nav.classList.toggle("nav-floating", uiPrefs.navMode === "floating");
  ["themeAuto","themeDark","themeLight","langZh","langEn","navTraditional","navFloating","paletteBlue","paletteSage","paletteLilac","paletteRose","paletteSand","navTraditional","navFloating"].forEach(id => {
    const el=document.getElementById(id); if(el) el.classList.remove("active");
  });
  const activeIds = {auto:"themeAuto",dark:"themeDark",light:"themeLight",zh:"langZh",en:"langEn",traditional:"navTraditional",floating:"navFloating"};
  const paletteIds = {blue:"paletteBlue",sage:"paletteSage",lilac:"paletteLilac",rose:"paletteRose",sand:"paletteSand"};
  const paletteButton = document.getElementById(paletteIds[uiPrefs.palette || "blue"]);
  if (paletteButton) paletteButton.classList.add("active");
  ["theme","language","navMode"].forEach(k => { const el=document.getElementById(activeIds[uiPrefs[k]]); if(el) el.classList.add("active"); });
  document.documentElement.lang = uiPrefs.language === "en" ? "en" : "zh-CN";
  document.title = uiPrefs.language === "en" ? "AutoPurge Pro - Settings" : "AutoPurge Pro";
  // Translate exact static text nodes while preserving element structure and handlers.
  const reverseMap = Object.fromEntries(Object.entries(UI_EN).map(([zh,en]) => [en,zh]));
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    const raw = node.nodeValue, trimmed = raw.trim();
    if (!trimmed) continue;
    const translated = uiPrefs.language === "en" ? UI_EN[trimmed] : reverseMap[trimmed];
    if (translated) node.nodeValue = raw.replace(trimmed, translated);
  }
}


function quickFillRule(path) {
  const input=document.getElementById("inpNewRulePath");
  if(!input)return;
  input.value=path;
  input.focus();
}

// Theme mode supports system-following, light and dark. Monet-style palettes are selectable.




// File path preferences: persisted separately from the cleanup rules.
const PATH_FIELDS = ["storage_root","download","qq","wechat","telegram","bluetooth","images","videos","audio","apks","modules"];
const PATH_DEFAULTS = {
  storage_root:"/storage/emulated/0", download:"/storage/emulated/0/Download", qq:"/storage/emulated/0/QQfile_recv",
  wechat:"/storage/emulated/0/WeChat", telegram:"/storage/emulated/0/Telegram", bluetooth:"/storage/emulated/0/Bluetooth",
  images:"/storage/emulated/0/Pictures/AutoPurge", videos:"/storage/emulated/0/Movies/AutoPurge", audio:"/storage/emulated/0/Music/AutoPurge",
  apks:"/storage/emulated/0/安装包/AutoPurge", modules:"/storage/emulated/0/模块安装包/AutoPurge"
};
async function loadFilePaths() {
  let values = {...PATH_DEFAULTS};
  if (isKsuEnv()) {
    const raw = await readRootFile(FILE_PATHS.file_paths);
    raw.split(/\r?\n/).forEach(line => {
      const i = line.indexOf("="); if (i < 1) return;
      const key=line.slice(0,i).trim(), val=line.slice(i+1).trim();
      if (PATH_FIELDS.includes(key) && val) values[key]=val;
    });
  }
  PATH_FIELDS.forEach(key => { const el=document.getElementById(`path_${key}`); if(el) el.value=values[key]; });
}
async function saveFilePaths() {
  const values={};
  for (const key of PATH_FIELDS) {
    const el=document.getElementById(`path_${key}`); if(!el) continue;
    const val=el.value.trim();
    if (!val.startsWith("/storage/emulated/0/") && val !== "/storage/emulated/0" && !val.startsWith("/sdcard/" ) && val !== "/sdcard") { showToast("路径必须位于共享存储目录内"); el.focus(); return; }
    if (/(\.\.|[\n\r\"'`$\\|;&<>])/.test(val)) { showToast("路径包含不支持的字符"); el.focus(); return; }
    values[key]=val;
  }
  if (values.storage_root && !Object.values(values).every(v => v===values.storage_root || v.startsWith(values.storage_root+"/") || (values.storage_root==="/storage/emulated/0" && v.startsWith("/sdcard/")))) {
    showToast("所有扫描与归档路径必须位于扫描根目录内"); return;
  }
  const content=PATH_FIELDS.map(k=>`${k}=${values[k] || PATH_DEFAULTS[k]}`).join("\n")+"\n";
  if (!isKsuEnv()) { showToast("路径格式检查通过；请在 Root WebUI 中保存到设备"); return; }
  const ok=await writeRootFile(FILE_PATHS.file_paths,content,"600");
  showToast(ok?"文件路径已保存":"保存失败，请检查 Root 权限");
}
let currentLogCategory="all";
function openLogs() { switchTab("logs"); }
function switchLogCategory(category,button) {
  currentLogCategory=category;
  document.querySelectorAll(".log-category-tabs .seg-btn").forEach(el=>el.classList.remove("active"));
  if(button) button.classList.add("active");
  loadFeatureLogs();
}
async function loadFeatureLogs() {
  const out=document.getElementById("featureLogView"); if(!out) return;
  let lines="";
  if(isKsuEnv()) {
    const [clearRes, historyRes]=await Promise.all([
      execRootCmd(`tail -n 500 "${FILE_PATHS.clear_log}" 2>/dev/null`,12000),
      execRootCmd(`tail -n 500 "${FILE_PATHS.history_log}" 2>/dev/null`,12000)
    ]);
    lines=Array.from(new Set(`${clearRes.stdout||""}\n${historyRes.stdout||""}`.split(/\r?\n/).filter(Boolean))).join("\n");
    if(!lines && (clearRes.errno!==0 || historyRes.errno!==0)) lines="日志读取失败，请检查权限或日志文件路径。";
  } else {
    lines=["2026-11-06 12:00:00 [智能清理] 示例：清理任务完成","2026-11-06 12:01:00 [MT清理] 示例：规则检查完成","2026-11-06 12:02:00 [文件归位] 示例：文件归档完成","2026-11-06 12:03:00 [服务] 示例：服务状态正常"].join("\n");
  }
  const match={all:()=>true,clean:l=>/删除文件|删除目录|APK清理|模块残留/.test(l),mt:l=>/MT清理|MT管理器/.test(l),files:l=>/文件归位|文件整理/.test(l),service:l=>/服务|守护|定时|LogClear/.test(l)}[currentLogCategory]||(()=>true);
  const filtered=lines.split(/\r?\n/).filter(match);
  out.textContent=filtered.slice(-250).join("\n") || "该分类暂无日志记录。";
}

// File manager: scan first, then move only after explicit user action.
let fileTaskRunning = false;
async function scanUserFiles() {
  if (fileTaskRunning) { showToast("已有文件任务正在执行，请稍候"); return; }
  fileTaskRunning = true;
  if (!isKsuEnv()) {
    document.getElementById("scanTotal").textContent = "预览";
    document.getElementById("scanImages").textContent = "—";
    document.getElementById("scanVideos").textContent = "—";
    document.getElementById("scanApks").textContent = "—";
    document.getElementById("scanAudio").textContent = "—";
    document.getElementById("scanArchives").textContent = "—";
    showToast("预览模式无法读取设备文件，请在 Root WebUI 中扫描");
    fileTaskRunning = false; return;
  }
  const res = await execRootCmd(`sh "${CTL_SCRIPT}" scan_files`, 25000);
  if (res.errno !== 0) { showToast(res.stderr || "扫描未完成，请检查权限或目录访问"); fileTaskRunning = false; return; }
  try {
    const data = JSON.parse((res.stdout || "").trim().split("\n").pop());
    document.getElementById("scanTotal").textContent = Number(data.total || 0).toLocaleString();
    document.getElementById("scanImages").textContent = Number(data.images || 0).toLocaleString();
    document.getElementById("scanVideos").textContent = Number(data.videos || 0).toLocaleString();
    document.getElementById("scanApks").textContent = Number(data.apks || 0).toLocaleString();
    document.getElementById("scanAudio").textContent = Number(data.audio || 0).toLocaleString();
    document.getElementById("scanArchives").textContent = Number(data.archives || 0).toLocaleString();
    showToast("扫描完成：已统计可识别文件");
  } catch (_) { showToast("扫描失败，请检查 Root 权限或查看日志"); }
  fileTaskRunning = false;
}
async function organizeUserFiles() {
  if (fileTaskRunning) { showToast("已有文件任务正在执行，请稍候"); return; }
  if (!isKsuEnv()) { showToast("请在 Root WebUI 中执行真实文件整理"); return; }
  if (!window.confirm("将把识别到的媒体文件归入独立分类目录。不会主动删除文件，是否继续？")) return;
  fileTaskRunning = true;
  const res = await execRootCmd(`sh "${CTL_SCRIPT}" organize_files`, 45000);
  if (res.errno === 0) { showToast("文件归档任务已完成"); }
  else showToast("整理执行失败：" + (res.stderr || "请检查权限"));
  fileTaskRunning = false;
}
