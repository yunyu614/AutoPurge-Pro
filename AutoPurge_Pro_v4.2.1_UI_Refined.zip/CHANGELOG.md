# AutoPurge Pro v4.1.1

## Unified Cleanup & File Organization
- Merged the former Smart Cleanup and File Management tabs into one page named “清理与整理”.
- Moved all cleanup feature switches to the top of the unified page.
- Placed file category statistics, scan and archive actions directly below the switches.
- Removed the separate File Management bottom-navigation item; bottom navigation now has four evenly spaced entries.
- Kept legacy `switchTab("files")` links compatible by redirecting them to the unified page.

## v4.0.0 baseline

## Interface and information architecture
- Home is now a data-only dashboard: storage, cleanup statistics, rule counts and service state.
- Smart Cleanup contains compact feature switches only; verbose descriptions and duplicate actions were removed.
- File Management is focused on scanning and archiving.
- Rules Center now groups blacklist, whitelist, MT rules and editable file scan/archive paths.
- Settings contains appearance, global service configuration, schedule, complete feature guide and a dedicated Logs entry.
- Logs open in a separate view and can be filtered by cleanup, MT, file organization and service categories.
- Removed the custom wallpaper feature and its frontend handlers/styles.

## File path configuration
- Added persistent `FilePaths.conf` for storage root, download/QQ/WeChat/Telegram/Bluetooth sources and per-type archive destinations.
- File scan and organization now consume the configured paths.
- Archive targets remain separated by type: Pictures/AutoPurge, Movies/AutoPurge, Music/AutoPurge, 安装包/AutoPurge and 模块安装包/AutoPurge.

## Stability and safety
- Root WebView bridge calls are serialized to avoid concurrent bridge dispatch instability.
- File scan/organize actions reject overlapping runs.
- Added the blacklist-cleaning master option and exposed its state in status output.
- Kept APK deletion disabled by default; module update staging directories remain protected.

## v4.1.1
- Added visible manual execution controls to the unified Clean & Organize page: Run cleanup and MT-only cleanup.
- Connected the controls to the existing background cleanup task flow and button busy state.
