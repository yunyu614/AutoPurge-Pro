##########################################################################################
# AutoPurge Pro v3.0.0 安装脚本
# Author: liancan
##########################################################################################
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

# 音量键监听函数：音量+ 返回 0，音量- 返回 1
choose_key() {
    while true; do
        local key=$(getevent -qlc 1 2>/dev/null | awk '{ print $3 }')
        case "$key" in
            KEY_VOLUMEUP) return 0 ;;
            KEY_VOLUMEDOWN) return 1 ;;
        esac
    done
}

print_modname() {
    ui_print "===================================================="
    ui_print "   AutoPurge Pro v3.0.0"
    ui_print "   模块作者: liancan"
    ui_print "===================================================="
    ui_print " - 移除外部独立 APK，专注原生高效 WebUI"
    ui_print " - 新增: 多媒体/文件分类整理 (图片/视频/音频/模块包)"
    ui_print " - 新增: APK 缓存独立清理开关"
    ui_print " - 新增: 卸载模块残余清理独立开关"
    ui_print " - 优化: WebUI 状态栏沉浸、Monet 动态色与跟随系统"
    ui_print "===================================================="
}

on_install() {
    ui_print "- 正在解压模块核心文件..."
    unzip -o "$ZIPFILE" -x "META-INF/*" -x "install.sh" -d "$MODPATH" >/dev/null 2>&1

    TARGET_DIR="/data/media/0/Android/Clear/清理垃圾"
    mkdir -p "$TARGET_DIR/名单配置" "$TARGET_DIR/自定义定时设置"

    ui_print ""
    ui_print "------------- [ 功能定制向导 ] -------------"
    ui_print "  提示：按 [音量+] = 开启，按 [音量-] = 关闭"
    ui_print "--------------------------------------------"

    ui_print ">> [1/3] 是否开启【APK 安装包独立清理】？"
    if choose_key; then
        ui_print "      -> 状态: [开启]"
        SET_APK="true"
    else
        ui_print "      -> 状态: [关闭]"
        SET_APK="false"
    fi

    ui_print ""
    ui_print ">> [2/3] 是否开启【卸载模块残留清理】？"
    if choose_key; then
        ui_print "      -> 状态: [开启]"
        SET_MOD_RESIDUE="true"
    else
        ui_print "      -> 状态: [关闭]"
        SET_MOD_RESIDUE="false"
    fi

    ui_print ""
    ui_print ">> [3/3] 是否开启【文件智能分类整理】(图片/视频/音频/模块)？"
    if choose_key; then
        ui_print "      -> 状态: [开启]"
        SET_ORGANIZE="true"
    else
        ui_print "      -> 状态: [关闭]"
        SET_ORGANIZE="false"
    fi
    ui_print "--------------------------------------------"
    ui_print ""

    if [ ! -f "$TARGET_DIR/配置.conf" ]; then
        cp -f "$MODPATH/Configuration_File/配置.conf" "$TARGET_DIR/配置.conf"
    fi

    set_conf() {
        local k="$1" v="$2" f="$3"
        if grep -q "^[[:space:]]*${k}[[:space:]]*=" "$f" 2>/dev/null; then
            sed -i "s|^[[:space:]]*${k}[[:space:]]*=.*|${k}=${v}|g" "$f"
        else
            echo "${k}=${v}" >> "$f"
        fi
    }

    set_conf "apk_cleaning" "$SET_APK" "$TARGET_DIR/配置.conf"
    set_conf "module_residue_cleaning" "$SET_MOD_RESIDUE" "$TARGET_DIR/配置.conf"
    set_conf "file_organize" "$SET_ORGANIZE" "$TARGET_DIR/配置.conf"

    if [ ! -f "$TARGET_DIR/名单配置/黑名单.conf" ]; then
        cp -f "$MODPATH/Configuration_File/名单配置/黑名单.conf" "$TARGET_DIR/名单配置/黑名单.conf"
    fi
    if [ ! -f "$TARGET_DIR/名单配置/白名单.conf" ]; then
        cp -f "$MODPATH/Configuration_File/名单配置/白名单.conf" "$TARGET_DIR/名单配置/白名单.conf"
    fi
    if [ ! -f "$TARGET_DIR/名单配置/MT.conf" ]; then
        cp -f "$MODPATH/Configuration_File/名单配置/MT.conf" "$TARGET_DIR/名单配置/MT.conf"
    fi
    if [ ! -f "$TARGET_DIR/自定义定时设置/定时设置.conf" ]; then
        cp -f "$MODPATH/Configuration_File/自定义定时设置/定时设置.conf" "$TARGET_DIR/自定义定时设置/定时设置.conf"
    fi

    cp -f "$MODPATH/Configuration_File/自定义定时设置/Timing_Settings.sh" "$TARGET_DIR/自定义定时设置/Timing_Settings.sh"

    [ ! -f "$TARGET_DIR/Counter" ] && printf "目录=0\n文件=0\n" > "$TARGET_DIR/Counter"
    [ ! -f "$TARGET_DIR/Clear.log" ] && touch "$TARGET_DIR/Clear.log"
    [ ! -f "$TARGET_DIR/History_Files.log" ] && touch "$TARGET_DIR/History_Files.log"

    rm -rf "$MODPATH/Configuration_File"
    ui_print "- 正在配置执行权限..."
}

set_permissions() {
    set_perm_recursive "$MODPATH" 0 0 0755 0644
    set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
    set_perm_recursive "$MODPATH/Service_Config" 0 0 0755 0755
    set_perm "$MODPATH/Main.sh" 0 0 0755
    set_perm "$MODPATH/action.sh" 0 0 0755
    set_perm "$MODPATH/service.sh" 0 0 0755
    set_perm "$MODPATH/uninstall.sh" 0 0 0755
    chmod 2770 "$TARGET_DIR/名单配置" 2>/dev/null
    chmod 2770 "$TARGET_DIR/自定义定时设置" 2>/dev/null
    chmod 0755 "$TARGET_DIR/自定义定时设置/Timing_Settings.sh" 2>/dev/null
    find "$TARGET_DIR/" -type f -name "*.conf" -exec chmod 644 {} + 2>/dev/null
    ui_print "- 安装完成！请在 KernelSU / APatch / MMRL 中打开 WebUI 使用。"
}
